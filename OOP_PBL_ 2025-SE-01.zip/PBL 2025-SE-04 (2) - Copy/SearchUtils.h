#ifndef SEARCHUTILS_H
#define SEARCHUTILS_H

#include <vector>

using namespace std;

template <class T, class Predicate>
T* findFirst(vector<T*>& collection, Predicate condition)
{
    for (int i = 0; i < (int)collection.size(); i++)
    {
        if (condition(collection[i]))
            return collection[i];
    }

    return NULL;
}

#endif
