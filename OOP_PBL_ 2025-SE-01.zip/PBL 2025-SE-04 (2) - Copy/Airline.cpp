#include "Airline.h"
#include "SearchUtils.h"
#include <sstream>   

Airline::~Airline()
{
    for (int i = 0; i < (int)flights.size(); i++)
        delete flights[i];

    for (int i = 0; i < (int)passengers.size(); i++)
        delete passengers[i];

    for (int i = 0; i < (int)tickets.size(); i++)
        delete tickets[i];
}

/* ================= PRIVATE HELPER ================= */

bool Airline::isRegisteredPassenger(string pid)
{
    return passengerMap.find(pid) != passengerMap.end();
}

/* ================= FLIGHT ================= */

void Airline::addFlight()
{
    string no, oCity, oCountry, dCity, dCountry, dt;
    int seats;
    int choice;

    while (true)
    {
        cout << "1=Domestic  2=International  3=Charter\n";
        cout << "Select Type: ";
        cin >> choice;

        if (choice >= 1 && choice <= 3)
            break;

        cout << "Invalid choice!\n";
    }

    cout << "Flight No: ";    cin >> no;
    cout << "Origin City: ";  cin >> oCity;
    cout << "Origin Country: "; cin >> oCountry;
    cout << "Destination City: "; cin >> dCity;
    cout << "Destination Country: "; cin >> dCountry;
    cout << "Date (DD-MM-YYYY): "; cin >> dt;
    cout << "Total Seats: "; cin >> seats;

    string origin      = oCity + "(" + oCountry + ")";
    string destination = dCity + "(" + dCountry + ")";

    if (choice == 1)
        flights.push_back(new DomesticFlight(no, origin, destination, dt, seats));
    else if (choice == 2)
        flights.push_back(new InternationalFlight(no, origin, destination, dt, seats));
    else
    {
        string holder;
        cout << "Contract Holder: ";
        cin >> holder;
        flights.push_back(new CharterFlight(no, origin, destination, dt, seats, holder));
    }

    cout << "Flight Added Successfully!\n";
}

void Airline::listFlights()
{
    if (flights.empty())
    {
        cout << "No flights available!\n";
        return;
    }
    for (int i = 0; i < (int)flights.size(); i++)
        flights[i]->show();
}

void Airline::removeFlight()
{
    if (flights.empty())
    {
        cout << "No flights available!\n";
        return;
    }

    string no;
    cout << "Flight No: ";
    cin >> no;

    for (int i = 0; i < (int)flights.size(); i++)
    {
        if (flights[i]->getFlightNo() == no)
        {
            delete flights[i];
            flights.erase(flights.begin() + i);
            cout << "Flight Removed!\n";
            return;
        }
    }

    cout << "Error: Flight does not exist!\n";
}

void Airline::searchFlight()
{
    string no;
    cout << "Flight No: ";
    cin >> no;

    for (int i = 0; i < (int)flights.size(); i++)
    {
        if (flights[i]->getFlightNo() == no)
        {
            flights[i]->show();
            return;
        }
    }

    cout << "Flight Not Found!\n";
}

/* ================= PASSENGER ================= */

void Airline::registerPassenger()
{
    string id, name;
    int type;

    cout << "Passenger ID: ";
    cin >> id;

    if (isRegisteredPassenger(id))
    {
        cout << "Error: Passenger ID already exists!\n";
        return;
    }

    cout << "Name: ";
    cin >> name;

    cout << "Type (1=Economy  2=Business  3=FirstClass): ";
    cin >> type;

 Passenger* p;

if (type == 1)
    p = new EconomyPassenger(id, name);
else if (type == 2)
    p = new BusinessPassenger(id, name);
else
    p = new FirstClassPassenger(id, name);

passengers.push_back(p);
passengerMap[id] = p;

    cout << "Passenger Registered Successfully!\n";
}

void Airline::removePassenger()
{
    if (passengers.empty())
    {
        cout << "No passengers registered!\n";
        return;
    }

    string id;
    cout << "Passenger ID: ";
    cin >> id;

    for (int i = 0; i < (int)passengers.size(); i++)
    {
        if (passengers[i]->getId() == id)
        {
            delete passengers[i];
            passengers.erase(passengers.begin() + i);
            passengerMap.erase(id);
            cout << "Passenger Removed!\n";
            return;
        }
    }

    cout << "Error: Passenger does not exist!\n";
}

void Airline::listPassengers()
{
    if (passengers.empty())
    {
        cout << "No passengers registered!\n";
        return;
    }

    sort(passengers.begin(), passengers.end(),
        [](Passenger* a, Passenger* b)
        {
            return a->getName() < b->getName();
        });

    cout << "\n--- PASSENGERS (SORTED BY NAME) ---\n";

    for (int i = 0; i < (int)passengers.size(); i++)
    {
        cout << passengers[i]->getName()
             << " (" << passengers[i]->getId()
             << ") [" << passengers[i]->type() << "]"
             << " | Baggage: " << passengers[i]->baggageAllowance() << " kg"
             << " | Loyalty: " << passengers[i]->loyaltyMultiplier() << "x"
             << " | Refund: " << passengers[i]->refundPercentage() << "%"
             << endl;
    }
}

/* ================= BOOKING DETAILS ================= */

void Airline::passengerBookingDetails()      // <-- FIXED: proper Airline:: scope
{
    if (tickets.empty())
    {
        cout << "No bookings available!\n";
        return;
    }

    cout << "\n===== PASSENGER BOOKING DETAILS =====\n";

    for (int i = 0; i < (int)tickets.size(); i++)
    {
        string pid = tickets[i]->pid;
        string fid = tickets[i]->fid;

        Passenger* p = findFirst(passengers,
    [pid](Passenger* passenger)
    {
        return passenger->getId() == pid;
    });

Flight* f = NULL;
       
       
       f = findFirst(flights,
    [fid](Flight* flight)
    {
        return flight->getFlightNo() == fid;
    });
    
    
        cout << "\n--------------------------\n";

        if (p != NULL)
        {
            cout << "Passenger Name : " << p->getName() << endl;
            cout << "Passenger ID   : " << p->getId()   << endl;
            cout << "Passenger Type : " << p->type()    << endl;
        }

        if (f != NULL)
            cout << "Flight No      : " << f->getFlightNo() << endl;

        cout << "Seat No        : " << tickets[i]->seat << endl;
        cout << "Fare           : " << tickets[i]->fare << endl;
        cout << "Status         : " << tickets[i]->status << endl;
    }
}

/* ================= BOOKING ================= */

void Airline::bookTicket()
{
    if (flights.empty())
    {
        cout << "No flights available!\n";
        return;
    }

    string pid, fid;
    int seat;

    cout << "Passenger ID: "; cin >> pid;
    cout << "Flight ID: ";    cin >> fid;
    cout << "Seat No: ";      cin >> seat;

    if (!isRegisteredPassenger(pid))
    {
        cout << "Error: Passenger not registered!\n";
        return;
    }

    Flight* f = NULL;

    for (int i = 0; i < (int)flights.size(); i++)
    {
        if (flights[i]->getFlightNo() == fid)
        {
            f = flights[i];
            break;
        }
    }

    if (f == NULL)
    {
        cout << "Error: Flight not found!\n";
        return;
    }

    if (!f->bookSeat())
        throw FlightFullException();

    double fare = f->baseFare();
    f->addRevenue(fare);
    tickets.push_back(new Ticket(pid, fid, seat, fare , "Booked"));

    cout << "Booking Successful! Fare = " << fare << "\n";
}

/* ================= CANCEL ================= */

void Airline::cancelTicket()
{
    string pid, fid;

    cout << "Passenger ID: ";
    cin >> pid;

    cout << "Flight ID: ";
    cin >> fid;

    // Find passenger
  unordered_map<string, Passenger*>::iterator it;
it = passengerMap.find(pid);

if (it == passengerMap.end())
{
    throw InvalidCancellationException();
}

Passenger* p = it->second;

    if (p == NULL)
    {
        throw InvalidCancellationException();
    }

    // Find ticket
    for (int i = 0; i < (int)tickets.size(); i++)
    {
        Ticket temp(pid, fid, 0, 0, "Booked");

        if (*tickets[i] == temp)
        {
            double refund = tickets[i]->fare *
                            p->refundPercentage() / 100.0;

            cout << "Passenger Type = " << p->type() << endl;
            cout << "Refund Percentage = "
                 << p->refundPercentage() << "%" << endl;
            cout << "Refund Amount = " << refund << endl;

            tickets[i]->status = "Cancelled";

            cout << "Ticket Cancelled Successfully!\n";

            return;
        }
    }

    throw InvalidCancellationException();
}

/* ================= REPORTS ================= */

void Airline::occupancyReport()
{
    if (flights.empty())
    {
        cout << "No flights available!\n";
        return;
    }

    cout << "\n--- FLIGHT OCCUPANCY REPORT ---\n";

    for (int i = 0; i < (int)flights.size(); i++)
        cout << flights[i]->getFlightNo()
             << " | Occupancy: " << flights[i]->occupancy() << "%\n";
}

void Airline::report()
{
    if (flights.empty())
    {
        cout << "No flights available!\n";
        return;
    }

    cout << "\n--- REVENUE REPORT ---\n";

    for (int i = 0; i < (int)flights.size(); i++)
        cout << *flights[i] << endl;
}

/* ================= SAVE / LOAD ================= */

void Airline::save()
{
    ofstream file("data.txt");

    for (int i = 0; i < (int)flights.size(); i++)
        file << flights[i]->getFlightNo() << endl;

    cout << "Saved!\n";
}

void Airline::saveState()
{
    ofstream file("state.txt");
    if (!file.is_open())
    {
        cout << "Error: Could not save state!\n";
        return;
    }

    // --- Flights ---
    file << "Flights:\n";
    for (int i = 0; i < (int)flights.size(); i++)
    {
        file << flights[i]->type()              << " "
             << flights[i]->getFlightNo()       << " "
             << flights[i]->getAvailableSeats() << " "
             << flights[i]->getTotalSeats()     << " "
             << flights[i]->getRevenue()        << "\n";
    }

    // --- Passengers ---
    file << "Passengers:\n";
    for (int i = 0; i < (int)passengers.size(); i++)
    {
        file << passengers[i]->type() << " "
             << passengers[i]->getId() << " "
             << passengers[i]->getName() << "\n";
    }

    // --- Tickets ---
    file << "Tickets:\n";
    for (int i = 0; i < (int)tickets.size(); i++)
    {
        file << tickets[i]->pid  << " "
             << tickets[i]->fid  << " "
             << tickets[i]->seat << " "
             << tickets[i]->fare << " "
			 << tickets[i]->status << "\n";
    }

    cout << "System State Saved!\n";
}

void Airline::loadState()
{
    // Pehle state.txt try karo (saved session),
    // warna sample_data.txt se initial data load karo
    ifstream file("state.txt");
    bool usingSample = false;

    if (!file.is_open())
    {
        file.open("sample_data.txt");
        usingSample = true;
    }

    if (!file.is_open())
    {
        cout << "No saved state found. Starting fresh.\n";
        return;
    }

    string line;
    string section = "";

    while (getline(file, line))
    {
        // Section headers detect karo
        if (line == "Flights:")    { section = "F"; continue; }
        if (line == "Passengers:") { section = "P"; continue; }
        if (line == "Tickets:")    { section = "T"; continue; }
        if (line.empty())          continue;

        istringstream ss(line);

        if (section == "F")
        {
            string type, no;
            int avail, total;
            double rev;
            ss >> type >> no >> avail >> total >> rev;

            Flight* f = NULL;
            if      (type == "Domestic")      f = new DomesticFlight(no, "", "", "", total);
            else if (type == "International") f = new InternationalFlight(no, "", "", "", total);
            else if (type == "Charter")       f = new CharterFlight(no, "", "", "", total, "");

            if (f)
            {
                // booked seats restore karo
                int booked = total - avail;
                for (int i = 0; i < booked; i++) f->bookSeat();
                f->addRevenue(rev);
                flights.push_back(f);
            }
        }
        else if (section == "P")
        {
            string type, id, name;
            ss >> type >> id >> name;

        Passenger* p = NULL;

if (type == "Economy")
    p = new EconomyPassenger(id, name);
else if (type == "Business")
    p = new BusinessPassenger(id, name);
else if (type == "FirstClass")
    p = new FirstClassPassenger(id, name);

if (p != NULL)
{
    passengers.push_back(p);
    passengerMap[id] = p;
}

        }
        
        else if (section == "T")
        {
            string pid, fid , status;
            int seat;
            double fare;
            ss >> pid >> fid >> seat >> fare >> status;
            tickets.push_back(new Ticket(pid, fid, seat, fare, status));
        }
    }

    if (usingSample)
        cout << "Sample data loaded successfully!\n";
    else
        cout << "System State Restored! ("
             << flights.size()    << " flights, "
             << passengers.size() << " passengers, "
             << tickets.size()    << " tickets)\n";
}
