#ifndef PASSENGER_H
#define PASSENGER_H

#include <iostream>
#include <string>
using namespace std;

/* ===================== PASSENGER ===================== */
class Passenger {
protected:
    string id, name;

public:
    Passenger(string i, string n);
    virtual ~Passenger();

    virtual string type() const = 0;
    
    virtual double baggageAllowance() const = 0;
virtual double loyaltyMultiplier() const = 0;
virtual double refundPercentage() const = 0;

    string getId() const;
    string getName() const;
};

/* ===================== ECONOMY ===================== */
class EconomyPassenger : public Passenger {
public:
    EconomyPassenger(string i, string n);

    string type() const override;
    double baggageAllowance() const override;
	 double loyaltyMultiplier() const override;
	  double refundPercentage() const override;
};

/* ===================== BUSINESS ===================== */
class BusinessPassenger : public Passenger {
public:
    BusinessPassenger(string i, string n);

    string type() const override;
    
    double baggageAllowance() const override;
	 double loyaltyMultiplier() const override;
	  double refundPercentage() const override;
};

/* ===================== FIRST CLASS ===================== */
class FirstClassPassenger : public Passenger {
public:
    FirstClassPassenger(string i, string n);

    string type() const override;
    double baggageAllowance() const override;
	 double loyaltyMultiplier() const override;
	  double refundPercentage() const override;
};

#endif
