#include "Passenger.h"

/* ===================== PASSENGER ===================== */

Passenger::Passenger(string i, string n)
{
    id = i;
    name = n;
}

Passenger::~Passenger()
{
}

string Passenger::getId() const
{
    return id;
}

string Passenger::getName() const
{
    return name;
}

/* ===================== ECONOMY ===================== */

EconomyPassenger::EconomyPassenger(string i, string n)
    : Passenger(i, n)
{
}

string EconomyPassenger::type() const
{
    return "Economy";
}

double EconomyPassenger::baggageAllowance() const
{
    return 20;
}

double EconomyPassenger::loyaltyMultiplier() const {
 return 1.0;} // Example: 1x 
 
double EconomyPassenger::refundPercentage() const {
 return 50.0; } // Example: 50% 
 

/* ===================== BUSINESS ===================== */

BusinessPassenger::BusinessPassenger(string i, string n)
    : Passenger(i, n)
{
}

string BusinessPassenger::type() const
{
    return "Business";
}


double BusinessPassenger::baggageAllowance() const
{
    return 30;
}

double BusinessPassenger::loyaltyMultiplier() const {
 return 1.5;}
 
 double BusinessPassenger::refundPercentage() const { 
 return 75.0;} // Example: 75% }
 

/* ===================== FIRST CLASS ===================== */

FirstClassPassenger::FirstClassPassenger(string i, string n)
    : Passenger(i, n)
{
}

string FirstClassPassenger::type() const
{
    return "FirstClass";
}
double FirstClassPassenger::baggageAllowance() const { return 40;} // Example: 40 kg }
double FirstClassPassenger::loyaltyMultiplier() const { return 2.0;} // Example: 2x }
double FirstClassPassenger::refundPercentage() const { return 90.0;} // Example: 90% }
