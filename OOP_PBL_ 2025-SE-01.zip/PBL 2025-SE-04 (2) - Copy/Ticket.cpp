#include "Ticket.h"

/* ===================== TICKET ===================== */

Ticket::Ticket(string p, string f, int s, double fa , string st)
{
    pid = p;
    fid = f;
    seat = s;
    fare = fa;
    status = st;
}

/* ================= OPERATOR OVERLOADING ================= */

ostream& operator<<(ostream& out, const Ticket& t)
{
    out << "Passenger ID: " << t.pid
        << " | Flight ID: " << t.fid
        << " | Seat: " << t.seat
        << " | Fare: " << t.fare
		<< " | Status: " << t.status;
    return out;
}

bool Ticket::operator==(const Ticket& t)
{
    return (pid == t.pid && fid == t.fid);
}
